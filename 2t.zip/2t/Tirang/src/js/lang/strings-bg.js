// ** I18N
if (typeof (Calendar) != "undefined") {
    Calendar._DN = new Array
    ("неделя",
     "понеделник",
     "вторник",
     "сряда",
     "четвъртък",
     "петък",
     "събота",
     "неделя");
        Calendar._MN = new Array
    ("януари",
     "февруари",
     "март",
     "април",
     "май",
     "юни",
     "юли",
     "август",
     "септември",
     "октомври",
     "ноември",
     "декември");

    // tooltips
    Calendar._TT = {};
    Calendar._TT["TOGGLE"] = "Toggle first day of week";
    Calendar._TT["PREV_YEAR"] = "Предишна година";
    Calendar._TT["PREV_MONTH"] = "Предишен месец";
    Calendar._TT["GO_TODAY"] = "ДНЕС";
    Calendar._TT["NEXT_MONTH"] = "Следващ месец";
    Calendar._TT["NEXT_YEAR"] = "Следваща година";
    Calendar._TT["SEL_DATE"] = "Изберете дата";
    Calendar._TT["DRAG_TO_MOVE"] = "Влачи за да преместиш";
    Calendar._TT["PART_TODAY"] = " (днес)";
    Calendar._TT["MON_FIRST"] = "Display Monday first";
    Calendar._TT["SUN_FIRST"] = "Display Sunday first";
    Calendar._TT["CLOSE"] = "затвори";
    Calendar._TT["TODAY"] = "днес";

    // date formats
    Calendar._TT["DEF_DATE_FORMAT"] = "dd.mm.y";
    Calendar._TT["TT_DATE_FORMAT"] = "D, M d";

    Calendar._TT["WK"] = "wk";
}
if (typeof $ != 'undefined') {
    $(function () {
		if($.format && $.format.locale)
			$.format.locale({
				date: {
					format: 'dd.MM.yyyy',
					monthsFull: ['Януари', 'Февруари', 'Март', 'Април', 'Май', 'Юни', 'Юли', 'Август', 'Септември', 'Октомври', 'Ноември', 'Декември'],
					monthsShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					daysFull: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
					daysShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
					timeFormat: 'hh:mm tt',
					shortDateFormat: 'dd.MM.yyyy',
					longDateFormat: 'dddd, MMMM dd, yyyy'
				},
				number: {
					format: '0.00',
					groupingSeparator: ',',
					decimalSeparator: '.'
				}
			});
    });
}

var STR_INCORRECT_FORMAT = "Некоректен формат: ";
var STR_DATE_FORMAT = "дд.мм.гггг";
var STR_AMOUNT_FORMAT_DESC = "От 1 до 11 цифри, десетична точка или запетая, от 0 до 2 цифри. \nПримери: '123,45', '6.15', '0.1'";
var STR_AMOUNT_RESTRICTION = "Сумата не може да бъде отрицателна или нула."
var STR_YES = "Да";
var STR_NO = "Не";

var STR_LOADING = "ЗАРЕЖДАНЕ";
var STR_INVALID_NUM_MVTS = "Трябва да изберете 1 или 2 движения.";
var STR_AT_LEAST_1_ACC = "Изберете поне една сметка.";
var STR_ONLY_1_ACC = "Не сте избрали сметка.";
var STR_ONLY_1_CNTR = "Изберете точно една страна.";
var STR_ONLY_1_TEMPL = "Изберете точно един образец.";
var STR_MUST_SEL_BAE = "Трябва да изберете банков клон.";
var STR_ONLY_1_TYPE = "Изберете точно един тип";
var STR_ONLY_1_PRVD = "Не сте избрали учебно заведение.";
var STR_ONLY_1_SRVC = "Не сте избрали такса.";
var STR_ONLY_1_TRMNL = "Не сте избрали терминал.";
var STR_ONLY_1_FUND = "Не сте избрали договорен фонд.";

var STR_MUST_SEL_WDAY = "Изберете ден от седмицата.";
var STR_MUST_SEL_MDAY = "Изберете ден от месеца.";

var STR_SAME_BAES = "RINGS не може да бъде избран при вътрешен превод.";

var STR_ORDER_100000_WARN = "При превод на сума по-голяма от 100 000 BGN трябва да е избрано RINGS.";
var STR_INV_NOTIF_NAME = "Невалидно име.";
var STR_INV_SUBSCR_NAME = "Невалидно име.";

var STR_INV_NOTIF_FROM_AMT = "Невалидна сума от";
var STR_INV_NOTIF_TO_AMT = "Невалидна сума до";

var strLang="bg-BG";
var STR_RINGS="Избрали сте плащане през системата RINGS. Сигурни ли сте?";

var STR_BISERA_CHECK = "Въвели сте невалиден символ за системата Бисера/РИНГС, който в момента е заменен с '?'. Моля, проверете въведените данни.";

var STR_NO_CAPICOM = "Вашия браузър не може да работи с цифрови подписи!" ;
var STR_CONFIRM = "Сигурни ли сте?";
var STR_FOREIGN_CORRBANK = "Въведете име, град и държава на кореспондент или SWIFT код";
var STR_FOREIGN_PAYEEBANK = "Въведете име, град и държава на банка на бенефициента или SWIFT код";

var STR_INTERNAL_FOREIGN = "Сметките трябва да са в една и съща валута";

var STR_EXPENSES = "Всички разходи трябва да са за сметка на наредителя";
var STR_DIRTYMONEY = "Моля, попълнете произход на парите";
var STR_DIRTYMONEY_STOP = "Сумата трябва да e по-малка от 30000 лева";
var STR_DIRTYMONEY_OTHER_VALIDATE = "Моля, попълнете други източници";
var STR_NO_DAYS_CHOSEN = "Няма избрани дни от седмицата";
var STR_NO_MONTHS_CHOSEN = "Няма избрани месеци от годината";
var STR_NO_NUMBER_CHOSEN = "Трябва да изберете валидно число";
var STR_NO_ACC_CHOSEN = "Няма избрани сметки";
var STR_ONLY_ONE_ACCEPTED = "Можете да получите информация по SMS само за 1 движение";

var STR_NOTBGN_ACCOUNT = "Сметката на получателя трябва да е левова.";
var STR_NOTBUDGET_ACCOUNT = "Сметката трябва да започва с 5 или с 3.";
var STR_NOTBGN_ACCOUNT_PR = "Сметката на платеца трябва да е левова.";var STR_WRONG_ACCOUNTS = "Избрали сте невалидни сметки.";
var STR_WRONG_LIMIT = "Некоректно въведен лимит.";
var STR_NO_CERTIFICATE = "Нямате сертификат.";
var STR_SAME_ACCOUNTS = "Сметките трябва да са в една валута";
var STR_NOT_SАME_ACCOUNTS = "Сметките не трябва да са в една валута";
var STR_DIF_ACCOUNTS = "Сметките трябва да са различни";
var STR_SIGN_OK = "Преводът може да бъде подписан.";
var STR_SIGN_NOTOK = "Преводът не може да бъде подписан.";
var STR_SIGN_OK_ASSETS = "Отмяната на поръчката може да бъде подписана.";
var STR_SIGN_NOTOK_ASSETS = "Отмяната на поръчката не може да бъде подписана.";
var STR_SIGN_NOTOK_DOCUMENTS = "Документите не могат да бъдат подписани.";
var STR_SIGN_OK_DOCUMENTS = "Документите могат да бъдат подписани.";

var STR_DATE_DAY="Невалиден ден от месец";
var STR_DATE_MONTH="Невалиден месец";
var STR_DATE_YEAR="Невалидна година - въведете 4 цифри между";
var STR_DATE_AND=" и ";
var STR_DATE_WRONG_PERIOD="Крайната дата е след началната";

var STR_SIGN_CAPICOM = "Нямате инсталиран компонент CAPICOM.";
var STR_SIGN_CNTSIGN = "Грешка при подписването";
var STR_MUST_SEL_BIC = "Трябва да изберете BIC код.";
var STR_PASSWORD_LENGTH = "Паролата трябва да е поне 8 и не повече от 20 символа.";
var STR_USERNAME_LENGTH = "Потребителското име трябва да е поне 5 символа";

var STR_UNIV_FEES_EGN = "Ако нямате ЕГН (ЛНЧ), въведете 9999999999 (десет броя деветки).";
var STR_UNIV_FEES_FNUMBER = "Ако нямате факултетен номер, въведете 000000 (шест броя нули).";
var STR_UNIV_CHOOSE = "Изберете учебно заведение.";
var STR_DATE_WRONG_UNIDATA = "Въведете реални данни поне за едно от двете полета ЕГН и факултетен номер.";
var STR_IDENTITY = "Необходимо е да бъде въведено едно от полетата БУЛСТАТ, ЛНЧ и ЕГН!";
var STR_IDENTITY2 = "Необходимо е да бъде въведено едно от полетата ЛНЧ и ЕГН!";

var STR_GLOBUL_NO_AMOUNT = "Не можете да платите - няма задължение.";
var STR_GLOBUL_HAVE_AMOUNT = "Не можете да платите - имате задължение.";

var STR_GLOBUL_LESS_AMOUNT = "Не можете да платите - сумата е недостатъчна.";
var STR_GLOBUL_MUCH_AMOUNT = "Не можете да платите - сумата е по-голяма от допустимото.";

var STR_GLOBUL_MUST_CHECK = "Моля, проверете задължението си.";

var STR_SIGN_OK_MULT = "Подписване успешно.";
var STR_SIGN_NOTOK_MULT = "Подписване неуспешно.";
var STR_NO_RATE_AVAILABLE ="Тази операция може да бъде извършена във времето от 8.30 до 17.00 часа в работни дни."
var STR_RANGE_BETWEEN = " трябва да е в интервала ";
var STR_STAT_FORM_COUNTRY = "За чуждестранно лице не е допустимо да бъде посочвана държава България!";

var STR_INCORRECT_FORMAT_LATIN = "Попълнете данните на латиница в поле : ";
var STR_SWIFT_INDIVIDUAL_LIMIT = "Валутните преводи за индивидуални потребители са ограничени до 25000 BGN.";

var STR_PLEASE_SELECT_VALUE = "Моля, изберете стойност.";

var STR_SIGN_LOAN_OK = "Искането за кредит може да бъде подписано.";
var STR_SIGN_LOAN_NOTOK = "Искането за кредит не може да бъде подписано.";

var STR_UNVALID_PASSWORD = "Невалидни стойности за парола.";
var STR_MUST_NOT_EXIST_IN = " не трябва да се съдържа в ";


var STR_PLEASE_CONFIRM = "Моля, потвърдете:";

var STR_TD_ACCEPT_CMN_COND = "Не сте приели условията за откриване на срочен виртуален депозит.";
var STR_PLEASE_WAIT = "моля, изчакайте...";
var STR_TD_ACCEPT_TERMS_NEW_ACC = "Не сте приели условията.";

var STR_INCORRECT_ID_NUMBER = "Номерът на личната карта не съответства на този в банковата система. Моля, посетете клон на Банка ДСК.";

var STR_MAX_AMOUNT = "Максимално допустимата сума е ";
var STR_MAX_PARTIAL_AMOUNT = "Максимално допустимата сума за предсрочно плащане е ";
var STR_EXACT_AMOUNT = "Сума трябва да е равна на ";

var STR_HASTODAY_TRANSACTION = "Има транзакции за деня - не може да се направи пълно погасяване.";
var STR_LOAN_AMOUNT_NULL = "Кредитът e погасен. Системата не допуска вноски по погасени кредити.";

var STR_CHOOSE_FILE = "Моля, изберете файл.";
var STR_CHOOSE_SERVICE = "Моля, изберете услуга.";
var STR_CHOOSE_INSURER = "Моля, изберете вид осигурител";
var STR_CHOOSE_MUNICIPALITY = "Моля, изберете община.";

 var ID_STR_SUBSCRIPTION_COMFIRM_DEL = "Сигурни ли сте, че искате да изтриете този абонамент?"

 var STR_INCORRECT_PARTIAL_AMOUNT = "Некоректен формат на частична сума";

 var STR_SWIFT_CHECK = "Въвели сте невалиден символ за системата SWIFT, който в момента е заменен с '.'. Моля, проверете въведените данни.";
 var STR_INCORRECT_INPUTS_DEFAULT_MSG = 'Данните в маркираните полета са некоректни.';

var STR_ERROR = "Грешка";
var STR_SESSION_EXPRED = "Сесията Ви е изтекла";
var STR_3DISSUE_VALIDATION = 'Не сте въвели промяна на парола или други регистрационни данни.';
var STR_ASSETS_DATEX = "Заповядайте в най-близкото до Вас поделение на “Банка ДСК” АД, определено за точка на дистрибуция на дялове на договорни фондове, за да подпишете Поръчка-Договор.";

var STR_INCORRECT_CARDHOLDER = "Моля, попълнете данните на латиница в поле : Картодържател";
var STR_ERR_IBAN_BAE = "Невалиден IBAN - грешен идентификатор на банка";
var ID_STR_REQUIRED_FIELD = "Полето е задължително.";
var ID_STR_SELECT_LIABILITY = "Моля, изберете задължение";

var STR_INCORRECT_DEPOSIT_AMOUNT = "Некоректен формат на авансово плащане";
var ID_STR_CERT_INVALID = "Невалиден сертификат";

var ID_STR_GADGET_EXTENDED = "Разширен изглед";
var ID_STR_GADGET_REMOVE = "Премахване";
var ID_STR_GADGET_MINIMIZE = "Минимизиране";
var ID_STR_GADGET_MAXIMIZE = "Максимизиране";
var ID_STR_GADGET_SETTINGS = "Настройки";
var ID_STR_GADGET_SETTINGS_CLOSE = "Затваряне на настройки";
var ID_STR_GADGET_REFRESH = "Обновяване";
var ID_STR_SELECT_DAY = "Моля, изберете поне един ден от месеца.";
var ID_STR_DAY_NOTIN_PERIOD = "Дефинирана е дата на превод, която не попада в зададения период.";
var ID_STR_START_DT_ONEYEAR = "Началната дата не може да е повече от една година напред.";
var ID_STR_START_END_DATE = "Крайна дата трябва да е по-голяма от начална.";
var ID_STR_PLACE_WIDGET_HERE = "Постави тук";
var ID_STR_NEW_PASS_HELP_TEXT = "Изискванията за новата парола са както следва:\nДължина – минимум 8 символа, максимум 30.\nДа съдържа едновременно:\n- Поне една цифра;\n- Поне една малка латинска буква;\nПоне една голяма латинска буква.";
var ID_STR_DOWNLOAD_FILE_ERROR = "Проблем при генериране на файл";
var ID_STR_CONFIRM = "Потвърди";
var ID_STR_DELETE = "Откажи";

var ID_STR_COMCHECK_SUCCESS = "Тестът за подписване е успешен";
var ID_STR_COMCHECK_FAIL = "Тестът за подписване е неуспешен";
var ID_STR_CERTCHECK_SUCCESS = "Тестът за заявяване на сертифиакт е успешен";
var ID_STR_CERTCHECK_FAIL = "Тестът за заявяване на сертифиакт е неуспешен";

var ID_STR_PAST_DATE_MSG = "Моля, изберете дата, която не е в миналото";
var ID_STR_REQUIRED_CALENDAR_DATE_MSG = "Моля, попълнете полето за дата";

var ID_STR_HIDE = "Скрий";

var ID_STR_BISS_MISSING_OR_NOT_INSTALLED = "Няма или не е инсталиран BISS";
var ID_STR_BISS_CHOOSING_CERTIFICATE_FAILED = "Грешка при избор на сертификат";
var ID_STR_ERROR_LOADING_ACCOUNTS = "Възникнала е грешка при зареждане на данни за сметки. Моля опитайте да наредите превода по-късно.";

var STR_PERIOD_FROM = "За период от";
var STR_PERIOD_TO = "до";
var STR_FOR_MONTH = "За месец";
var STR_FROM_BEGINNING_OF = "От началото на";

var STR_SCA_REPORT_MODAL_TITLE = "Допълнителна идентификация";
var STR_SCA_MODAL_TITLE = "Допълнителна идентификация";

var STR_EXB_TO_DSK_MODAL_TITLE = "Съответстваща сметка в Банка ДСК";