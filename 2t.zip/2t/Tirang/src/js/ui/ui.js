﻿/*
 * jQuery doTimeout
 * http://benalman.com/projects/jquery-dotimeout-plugin/
 */
(function ($) { var a = {}, c = "doTimeout", d = Array.prototype.slice; $[c] = function () { return b.apply(window, [0].concat(d.call(arguments))) }; $.fn[c] = function () { var f = d.call(arguments), e = b.apply(this, [c + f[0]].concat(f)); return typeof f[0] === "number" || typeof f[1] === "number" ? this : e }; function b(l) { var m = this, h, k = {}, g = l ? $.fn : $, n = arguments, i = 4, f = n[1], j = n[2], p = n[3]; if (typeof f !== "string") { i--; f = l = 0; j = n[1]; p = n[2] } if (l) { h = m.eq(0); h.data(l, k = h.data(l) || {}) } else { if (f) { k = a[f] || (a[f] = {}) } } k.id && clearTimeout(k.id); delete k.id; function e() { if (l) { h.removeData(l) } else { if (f) { delete a[f] } } } function o() { k.id = setTimeout(function () { k.fn() }, j) } if (p) { k.fn = function (q) { if (typeof p === "string") { p = g[p] } p.apply(m, d.call(n, i)) === true && !q ? o() : e() }; o() } else { if (k.fn) { j === undefined ? e() : k.fn(j === false); return true } else { e() } } } })(jQuery);


$(document).ready(function () {

    // Gadget Manager toggle 
    $("button.btnContent, .widgetManager .ui-icon-closethick").click(function () {
        $(".btnContent").toggleClass("opened");
        $(".widgetManager").toggleClass("active");
        return false;
    });

    // top navigation
    $('ul.main_menu').each(function () {

        var nav = $(this);
        $('a.selected').closest('li').addClass('selected');

        $('.navig1wrap').mouseover(function (e) {
            $(this).doTimeout('nav', 300, hideSelected, e.target);
        }).mouseout(function () {
            $(this).doTimeout('nav', 1000, showSelected);
        });

        nav
         .mouseover(function (e) {
             nav.doTimeout('main-nav', 300, over, e.target);
         }).mouseout(function () {
             nav.doTimeout('main-nav', 1000, out);
         });

        function over(elem) {
            var parent = $(elem).closest('li');
            out(parent);
            parent.children('a').addClass('hover');
            parent.children('.navig2wrap:hidden').css('z-index', '2').slideDown('fast');
        };

        function out(elem) {
            var parents = elem
              ? $(elem).closest('li').siblings()
              : nav.children();
            parents = parents.not('.selected');
            parents.children('.navig2wrap').hide();
            parents.children('a').removeClass('hover');
        };

        function hideSelected(elem) {
            if ($(elem).parents('li').hasClass('selected')) {
                return false;
            }
            else {
                $('.selected').removeClass('hover');
                $('.selected .navig2wrap').hide();
            }
        }

        function showSelected() {
            $('a.selected').addClass('hover');
            $('.selected .navig2wrap').slideDown('fast');
        };
    });

    // Capitalize button strings
    $("input.submit").each(function () {
        var buttonText = $(this).val();
        buttonText = buttonText.charAt(0).toUpperCase() + buttonText.slice(1);
        $(this).val(buttonText);
    });

    $("a.submit, button.submit").each(function () {
        var buttonText = $(this).text();
        buttonText = buttonText.charAt(0).toUpperCase() + buttonText.slice(1);
        $(this).text(buttonText);
    });


    // IE8 media-query fallback
    if (window.attachEvent) {

        function mediaqFallback() {

            w = document.documentElement.clientWidth;

            if (w < 1366) {
                document.body.className += ' narrow';
            }
            else if (w > 1366) {
                document.body.className = document.body.className.replace('narrow', '');
            }

        }

        window.attachEvent('onload', mediaqFallback);
        window.attachEvent('onresize', mediaqFallback);
    }

    // Set content top margin
    //function setTopMargin() {
    //    var menuH = $('.selected .navig2wrap').height();
    //    $('#content').css('margin-top', menuH + 10 + 'px')
    //}

    //if ($('.selected .navig2wrap')) {
    //    setTopMargin();
    //    $(window).resize(function () {
    //        setTopMargin();
    //    });
    //}

    // Login page resize
    //function resizeLogin() {

    //    var leftCol = $('#left'),
    //        rightCol = $('#right'),
    //        centerCol = $('#center'),
    //        spacingW = 10,
    //        wrapperW = $('#wrapper>.innerWrap').width();

    //    leftCol.width(225);
    //    rightCol.width(225);
    //    centerCol.css('margin-left', spacingW).css('margin-right', spacingW);
    //    centerCol.width(wrapperW - (leftCol.width() + rightCol.width()) - 24);
    //}

    //if ($('#wrapper').hasClass('login')) {
    //    resizeLogin()

    //    $(window).resize(function () {
    //        resizeLogin()
    //    });
    //}

});